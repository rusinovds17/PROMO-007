# PROMO-PRO Telegram Bot

Telegram бот для работы с документами (счета, договоры) и интеграцией с VK.ОРД.

## 🚀 Быстрый старт

### Требования

- Python 3.11+
- Docker и Docker Compose (опционально)

### Установка

1. Клонируйте репозиторий:
```bash
git clone https://github.com/AllVolLOAD/Promo_since.git
cd Promo_since
```

2. Скопируйте пример конфигурации и заполните:
```bash
cp config.example.py config.py
# Отредактируйте config.py и укажите ваш BOT_TOKEN
```

3. Установите зависимости:
```bash
pip install -r requirements.txt
```

4. Создайте необходимые файлы в `secrets/`:
```bash
# Файлы создадутся автоматически при первом запуске, или создайте вручную:
mkdir -p secrets/user_data
touch secrets/counters.json
touch secrets/metrics.json
touch secrets/vk_ord_tokens.json
touch secrets/vk_ord_state.json
```

### Запуск

#### Вариант 1: Напрямую через Python
```bash
python ПОЛИРОЛЬОТБИВКИ.py
```

#### Вариант 2: Через Docker
```bash
docker-compose build
docker-compose up -d
# Просмотр логов:
docker-compose logs -f
```

## 📁 Структура проекта

```
PROMO-PRO/
├── ПОЛИРОЛЬОТБИВКИ.py    # Основной файл бота
├── config.py              # Конфигурация (не в git, создайте из config.example.py)
├── config.example.py      # Пример конфигурации
├── requirements.txt       # Зависимости Python
├── Dockerfile             # Docker образ
├── docker-compose.yml     # Docker Compose конфигурация
├── secrets/               # Чувствительные данные (не в git)
│   ├── counters.json      # Счетчики документов
│   ├── metrics.json       # Метрики уникальных пользователей
│   ├── vk_ord_tokens.json # Токены VK.ОРД
│   ├── vk_ord_state.json  # Состояние VK.ОРД
│   └── user_data/         # Данные пользователей
├── templates/             # Шаблоны документов
└── generated/             # Сгенерированные документы
```

## 🔧 Конфигурация

Все настройки находятся в `config.py`:

- `BOT_TOKEN` - токен Telegram бота
- `VK_ORD_API_TOKEN` - токен VK.ОРД API
- `VK_ORD_API_BASE` - базовый URL VK.ОРД API
- `ADMIN_CHAT_ID` - ID группы для отправки метрик

## 📊 Команды бота

- `/start` - запуск бота
- `/stats` - статистика уникальных пользователей (отправляется в админ-чат)

## 🔒 Безопасность

Все чувствительные данные хранятся в папке `secrets/`, которая автоматически игнорируется git. 

**Важно:** После клонирования создайте файл `config.py` на основе `config.example.py` и заполните реальные токены.

## 📚 Документация

- **[PROJECT_DOCUMENTATION.md](PROJECT_DOCUMENTATION.md)** - Полная техническая документация
- **[ARCHITECTURE.md](ARCHITECTURE.md)** - Описание архитектуры проекта
- **[secrets/README.md](secrets/README.md)** - Описание папки secrets

## 🔍 Основные возможности

### Документооборот
- ✅ Генерация счетов-оферт (DOCX)
- ✅ Генерация договоров РИМ (DOCX)
- ✅ Поддержка множественных позиций в документах
- ✅ Автоматическая нумерация документов
- ✅ Поиск документов по ИНН

### Интеграция VK.ОРД
- ✅ Подключение кабинета VK.ОРД
- ✅ Создание контрагентов (Физ. лицо, Юр. лицо, ИП)
- ✅ Регистрация договоров (Оказание услуг, Посредничество, Доп. соглашения)
- ✅ Генерация креативов (ERID)
- ✅ Загрузка медиафайлов

### Аналитика
- ✅ Отслеживание уникальных пользователей
- ✅ Статистика по периодам (сегодня, неделя, месяц)
- ✅ Отправка метрик в админ-чат

## 📝 Лицензия

[Укажите лицензию если нужно]

