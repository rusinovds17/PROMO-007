# 📚 Техническая документация проекта PROMO-PRO

**Telegram бот для автоматизации работы с документами и интеграцией с VK.ОРД**

## 📋 Оглавление

1. [Обзор проекта](#обзор-проекта)
2. [Структура проекта](#структура-проекта)
3. [Основные функции](#основные-функции)
4. [Архитектура](#архитектура)
5. [API и интеграции](#api-и-интеграции)
6. [Конфигурация](#конфигурация)
7. [Установка и запуск](#установка-и-запуск)
8. [База данных и хранилище](#база-данных-и-хранилище)

---

## 🎯 Обзор проекта

PROMO-PRO - это Telegram бот на базе aiogram 3.12, предназначенный для:
- Автоматической генерации счетов-оферт и договоров РИМ в формате DOCX
- Интеграции с VK.ОРД API для регистрации контрагентов, договоров и креативов (ERID)
- Отслеживания метрик уникальных пользователей
- Поиска документов по ИНН

**Технологии:**
- Python 3.11+
- aiogram 3.12.0 (асинхронный Telegram Bot API)
- python-docx 1.1.2 (работа с Word документами)
- aiohttp (асинхронные HTTP запросы)
- Docker & Docker Compose (контейнеризация)

---

## 📁 Структура проекта

```
PROMO-PRO/
│
├── 📄 ПОЛИРОЛЬОТБИВКИ.py          # Основной файл бота (~4000 строк)
├── 📄 config.py                   # Конфигурация (НЕ в git, создать из config.example.py)
├── 📄 config.example.py           # Пример конфигурации
├── 📄 requirements.txt            # Зависимости Python
├── 📄 Dockerfile                  # Docker образ
├── 📄 docker-compose.yml          # Docker Compose конфигурация
├── 📄 .gitignore                  # Игнорируемые файлы
├── 📄 .dockerignore               # Игнорируемые файлы для Docker
├── 📄 README.md                   # Базовая документация
├── 📄 PROJECT_DOCUMENTATION.md    # Этот файл (полная техническая документация)
│
├── 📁 secrets/                    # ⚠️ Чувствительные данные (НЕ в git)
│   ├── counters.json              # Счетчики документов по дням
│   ├── metrics.json               # Метрики уникальных пользователей
│   ├── vk_ord_tokens.json         # Токены пользователей VK.ОРД
│   ├── vk_ord_state.json          # Состояние VK.ОРД (последние контрагенты, договоры)
│   ├── PASSWORD.txt               # Пароли (если используются)
│   ├── README.md                  # Описание папки secrets
│   ├── user_data/                 # Данные пользователей
│   │   └── {user_id}/
│   │       ├── invoices/          # Сгенерированные счета
│   │       ├── contracts/         # Сгенерированные договоры
│   │       └── tmp/               # Временные файлы
│   └── vk/                        # VK.ОРД API файлы (токены, пароли)
│       ├── API_TEST_ORD_UDOVIN(rusinov.ds).txt
│       └── API_VK_ORD_UDOVIN.txt
│
├── 📁 templates/                  # Шаблоны Word документов
│   ├── schet-oferta.docx          # Шаблон счета-оферты (одиночный)
│   ├── schet-oferta2-multi.docx   # Шаблон счета-оферты (множественный)
│   ├── schet-oferta2-multiPRO.docx # Шаблон счета-оферты (PRO версия)
│   ├── dogovor_rim.docx           # Шаблон договора РИМ (одиночный)
│   └── dogovor_rim2-multi.docx    # Шаблон договора РИМ (множественный)
│
├── 📁 generated/                  # Сгенерированные документы (legacy)
│   └── *.docx                     # Старые сгенерированные файлы
│
├── 📁 backup/                     # Резервные копии старых версий
│   └── [множество .py файлов]     # История разработки
│
├── 📁 files/                      # Вспомогательные файлы
│   ├── app.py                     # FastAPI приложение (webhook вариант, не используется)
│   ├── requirements.txt           # Старый файл зависимостей
│   └── test_*.py                  # Тестовые файлы
│
├── 📁 logo/                       # Логотипы проекта
├── 📁 stickerpack/                # Стикеры для бота
└── 📁 ОРДГОТОВНА99.py            # ⚠️ Старый файл с хардкод токенами (не используется)

```

---

## 🔧 Основные функции

### 1. Генерация документов

#### 📄 Счета-оферты (`InvoiceForm`)
**Поток:**
1. Ввод названия организации клиента
2. Ввод ИНН
3. Добавление позиций (канал, период, сумма)
4. Подтверждение и генерация DOCX

**Функции:**
- `start_invoice_flow()` - начало создания счета
- `invoice_customer_name()` - ввод названия организации
- `invoice_customer_inn()` - ввод ИНН
- `item_channel()`, `item_period()`, `item_amount()` - добавление позиций
- `form_invoice_entry()` - финальная генерация документа
- `manual_pnc_start()`, `manual_pnc_text()`, `manual_pnc_amount()` - ручной ввод позиций

**Файлы сохраняются в:** `secrets/user_data/{user_id}/invoices/`

#### 📄 Договоры РИМ (`ContractForm`)
**Поток:**
1. Ввод названия организации
2. Ввод ИНН
3. Ввод ОГРН
4. Ввод канала размещения
5. Ввод даты оказания услуг
6. Ввод периода
7. Ввод суммы
8. Подтверждение и генерация DOCX

**Функции:**
- `start_contract_flow()` - начало создания договора
- `contract_customer_name()`, `contract_customer_inn()`, `contract_customer_ogrn()` - ввод данных клиента
- `contract_placement_channel()`, `contract_service_date()`, `contract_service_period()`, `contract_amount()` - ввод условий
- `form_contract()` - финальная генерация

**Файлы сохраняются в:** `secrets/user_data/{user_id}/contracts/`

### 2. Интеграция с VK.ОРД API

#### 🔐 Авторизация
- `connect_vk_ord_lk()` - подключение к VK.ОРД кабинету
- `save_vk_ord_token()` - сохранение персонального токена пользователя
- `user_is_authorized()` - проверка авторизации

#### 👤 Управление контрагентами
**Поток создания контрагента:**
1. Выбор типа (Физ. лицо, Юр. лицо, ИП)
2. Ввод названия
3. Ввод ИНН
4. Ввод ОГРН (опционально)
5. Выбор ролей (Рекламодатель, Исполнитель, и т.д.)
6. Подтверждение и отправка в VK.ОРД API

**Функции:**
- `vk_ord_add_contractor()` - начало создания контрагента
- `vk_ord_person_type_step()` - выбор типа
- `vk_ord_person_name_step()`, `vk_ord_person_inn_step()`, `vk_ord_person_ogrn_step()` - ввод данных
- `vk_ord_person_roles_step()` - выбор ролей
- `vk_ord_person_confirm_step()` - финальное создание через API

#### 📋 Управление договорами VK.ОРД

**Типы договоров:**
1. **Дополнительное соглашение** (`vk_ord_additional_*`)
2. **Оказание услуг** (`vk_ord_service_*`)
3. **Посредничество** (`vk_ord_contract_*`)

**Функции:**
- `vk_ord_add_contract()` - начало создания договора
- `vk_ord_contract_type_step()` - выбор типа договора
- Множество step-функций для ввода данных
- `vk_ord_*_confirm_step()` - финальное создание через API

#### 🎨 Создание креативов (ERID)
**Поток:**
1. Ввод названия креатива
2. Ввод URL
3. Ввод периода размещения
4. Ввод текстов
5. Загрузка медиа (фото/видео)
6. Ввод ККТУ
7. Подтверждение и регистрация ERID

**Функции:**
- `vk_ord_add_creative()` - начало создания креатива
- `vk_ord_creative_name_step()`, `vk_ord_creative_url_step()`, и т.д.
- `vk_ord_upload_media()` - загрузка медиафайлов в VK.ОРД
- `vk_ord_creative_confirm_step()` - финальная регистрация

**API клиент:**
- `vk_ord_api_request()` - универсальная функция для запросов к VK.ОРД API

### 3. Система метрик

#### 📊 Уникальные пользователи
**Функции:**
- `track_unique_user(user_id)` - отслеживание нового пользователя (вызывается при `/start`)
- `get_unique_users_count()` - общее количество уникальных пользователей
- `get_unique_users_stats()` - статистика (всего, сегодня, за неделю, за месяц)

**Хранение:** `secrets/metrics.json`
```json
{
  "unique_users": {
    "user_id": "2025-11-26"
  },
  "total_count": 5,
  "daily_registrations": {
    "2025-11-26": 2
  }
}
```

#### 📈 Счетчики документов
**Функции:**
- `get_user_daily_sequence()` - генерация порядкового номера документа для пользователя за день
- `reset_user_daily_sequence()` - сброс счетчика
- `generate_number()` - генерация номера документа (формат: DD-MM-XX)

**Хранение:** `secrets/counters.json`
```json
{
  "2025-11-26": {
    "user_id": 5
  }
}
```

### 4. Поиск по ИНН

**Функции:**
- `start_inn_search()` - начало поиска
- `handle_inn_input()` - обработка введенного ИНН
- `build_inn_summary_from_paragraphs()` - построение сводки найденного документа

**Поиск:** сканирует все DOCX файлы в `generated/` и `secrets/user_data/` на наличие ИНН

### 5. Навигация и UI

**Клавиатуры:**
- `main_kb()` - главное меню
- `vk_lk_subscribe_kb()` - меню подписки VK.ОРД
- `step_kb()` - кнопки "Назад" / "На главную"
- `invoice_actions_kb()` - действия со счетом
- `contract_actions_kb()` - действия с договором
- Множество inline и reply клавиатур для VK.ОРД

**Хэндлеры навигации:**
- `handle_back()` - навигация назад
- `handle_cancel()` - отмена и возврат в главное меню

---

## 🏗️ Архитектура

### State Machine (FSM)

Бот использует aiogram FSM для управления состояниями пользователя:

**Состояния для счетов:**
```python
class InvoiceForm(StatesGroup):
    customer_name = State()
    customer_inn = State()
    item_channel = State()
    item_period = State()
    item_amount = State()
    manual_text = State()
    manual_amount = State()
    confirm = State()
```

**Состояния для договоров:**
```python
class ContractForm(StatesGroup):
    customer_name = State()
    customer_inn = State()
    customer_ogrn = State()
    placement_channel = State()
    service_date = State()
    service_period = State()
    amount = State()
    confirm = State()
```

**Состояния для VK.ОРД:**
Множество состояний для различных шагов создания контрагентов, договоров, креативов.

### Обработка DOCX

**Основные функции:**
- `render_docx_with_dynamic_rows()` - рендеринг DOCX с подстановкой данных и динамическими строками
- `_replace_in_paragraph()` - замена плейсхолдеров в параграфах
- `_replace_in_table()` - замена плейсхолдеров в таблицах
- `add_dynamic_rows_for_items()` - добавление динамических строк для позиций

**Плейсхолдеры:**
- `{{CONTRACT_NUMBER}}`, `{{CONTRACT_DATE}}`, `{{CUSTOMER_NAME}}`, и т.д.
- `{{ITEM_*}}` - для динамических строк

### Асинхронность

Все хэндлеры асинхронные (`async def`), используется aiogram 3.x async/await паттерн.

---

## 🔌 API и интеграции

### Telegram Bot API
- **Библиотека:** aiogram 3.12.0
- **Режим:** Long Polling (можно переключить на webhook через files/app.py)
- **Токен:** хранится в `config.py`

### VK.ОРД API
- **Base URL:** `https://api-sandbox.ord.vk.com` (sandbox) или `https://api.ord.vk.com` (production)
- **Аутентификация:** Bearer Token
- **Основная функция:** `vk_ord_api_request(user_id, method, path, json_body)`

**Endpoints используемые:**
- `PUT /v1/person/{external_id}` - создание/обновление контрагента
- `PUT /v1/contract/{external_id}` - создание/обновление договора
- `PUT /v3/creative/{external_id}` - создание/обновление креатива (ERID)
- `POST /v1/media` - загрузка медиафайлов

---

## ⚙️ Конфигурация

Все настройки в `config.py` (создается из `config.example.py`):

```python
# Telegram Bot
BOT_TOKEN = "your_token_here"
ADMIN_CHAT_ID = "1003460901654"  # ID группы для метрик

# VK.ОРД API
VK_ORD_API_BASE = "https://api-sandbox.ord.vk.com"
VK_ORD_API_TOKEN = "your_vk_token_here"
VK_ORD_PERSON_TYPE_JURIDICAL = "juridical"
VK_ORD_PERSON_TYPE_IP = "ip"
VK_ORD_PERSON_TYPE_INDIVIDUAL = "physical"
VK_ORD_PERSON_TYPE_DEFAULT = "juridical"

# Пути
TEMPLATE_INVOICE_SINGLE = "templates/schet-oferta.docx"
TEMPLATE_INVOICE_MULTI = "templates/schet-oferta2-multi.docx"
TEMPLATE_INVOICE_MULTI_PRO = "templates/schet-oferta2-multiPRO.docx"
TEMPLATE_CONTRACT = "templates/dogovor_rim.docx"
TEMPLATE_CONTRACT_MULTI = "templates/dogovor_rim2-multi.docx"

OUTPUT_DIR = "generated"
COUNTERS_FILE = "secrets/counters.json"
METRICS_FILE = "secrets/metrics.json"
```

---

## 🚀 Установка и запуск

### Требования
- Python 3.11+
- Docker (опционально)

### Установка зависимостей
```bash
pip install -r requirements.txt
```

### Запуск

**Вариант 1: Прямой запуск**
```bash
python ПОЛИРОЛЬОТБИВКИ.py
```

**Вариант 2: Docker**
```bash
docker-compose build
docker-compose up -d
docker-compose logs -f
```

---

## 💾 База данных и хранилище

Бот использует файловое хранилище (JSON файлы):

### `secrets/counters.json`
Счетчики документов по дням и пользователям:
```json
{
  "2025-11-26": {
    "user_id": 3
  }
}
```

### `secrets/metrics.json`
Метрики уникальных пользователей:
```json
{
  "unique_users": {
    "123456789": "2025-11-26"
  },
  "total_count": 10,
  "daily_registrations": {
    "2025-11-26": 2
  }
}
```

### `secrets/vk_ord_tokens.json`
Персональные токены пользователей VK.ОРД:
```json
{
  "user_id": "vk_api_token_here"
}
```

### `secrets/vk_ord_state.json`
Состояние VK.ОРД (последние контрагенты, договоры, регистр):
```json
{
  "user_id": {
    "last_person": {...},
    "last_contract": {...},
    "persons_registry": [...]
  }
}
```

### `secrets/user_data/{user_id}/`
Данные пользователя:
- `invoices/*.docx` - сгенерированные счета
- `contracts/*.docx` - сгенерированные договоры
- `tmp/` - временные файлы

---

## 📝 Команды бота

### Основные команды
- `/start` - запуск бота, отслеживание уникального пользователя
- `/stats` - отправка статистики уникальных пользователей в админ-чат
- `/feedback` или "обратная связь" - информация для связи

### Функции через меню
- 💳 Выставить «Счёт на оплату»
- 📃 Составить «Договор РИМ»
- 🔄 Сброс нумерации
- 🔍 Поиск по ИНН
- ➦ Перейти в кабинет «VK.ОРД»
- ⚙️ Обратная связь

---

## 🔒 Безопасность

- Все чувствительные данные в `secrets/` (в `.gitignore`)
- `config.py` не коммитится в git
- Токены хранятся в `config.py` или в `secrets/vk_ord_tokens.json`
- Пароли в `secrets/PASSWORD.txt`

---

## 🐛 Отладка

### Логирование
Бот использует стандартный Python logging:
```python
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
```

### Проверка конфигурации
```python
python -c "import config; print(config.BOT_TOKEN)"
```

### Тестирование функций
Файлы в `files/test_*.py` могут использоваться для тестирования.

---

## 📞 Контакты

Для вопросов и поддержки: указать контакты

---

**Дата последнего обновления:** 2025-11-26
**Версия:** 3.17 (ПОЛИРОЛЬОТБИВКИ.py)

